package synchronousKeyEncryption;
import java.io.UnsupportedEncodingException;
import java.nio.charset.StandardCharsets;
import java.util.Random;
/*my encryption scheme converts the message into an array of the byte value of the chars of the message, and then it scrambles the
 * order of the chars, and while the chars are being scrambled they have a number added to them. the key is an array of the indexes
 * that should be switched(the char at the elem of the key is switched with the char at the index of the elem of the key), and the
 * number added is the element of the key that you're up to. the bytes are then concatenated to a string and can be sent to the
 * decryptor. the decryptor converts the string into an array, and they use the key to unscramble the elems and subtract
 * the number from the chars, and then they convert the array of bytes to a string of chars.*/
//EAndD stands for Encryption And Decryption.
public class EAndD {
	private int[] key;
	private int keyGroupSize;
	public EAndD(int[] keyPar) {
		key = keyPar;
		/*if the message is 200 char.s long and the key is 100, then there are 2 key groups. the key is used twice on
		 * the message (once on the first 100 and once on the second 100).
		 * if the message is 110 char.s long then 90 random chars are appended to the message so that the key can be used
		 * on the last 10, so now you have 2 key groups.
		 * the decryptor should be sent an unencrypted number of how many char.s from the end of the decrypted message
		 * should be ignored (because they aren't part of the message, rather they were just added so the key could be
		 * used on the 10). in the case where no chars needed to be filled in (the message is 200 char.s) then
		 * the number that should be sent should be 0.
		 * i multiply the key length by 2 because the key only stores one element out of every pair of switched elements.
		 * the element stored is the index of the char that should switched with the char at the index of the key's
		 * element that is stored. i explain this more later.*/
		keyGroupSize = key.length * 2;
	}
	public String encrypt(String origMessage) throws UnsupportedEncodingException {
		Random rand = new Random();
		int missingChars = (int) (keyGroupSize * Math.ceil((double)origMessage.length() / keyGroupSize)) - origMessage.length();		
		String messagePlusChars = origMessage;
		for(int i = 0; i < missingChars; i++) {
			/*a number between 0 and 9 (including both) is generated. the reason i'm only using digits for the missing
			 * chars is because digits are more universal than any language; if a sniffer reads the encrypted message
			 * but sees char.s that are letters of a language that most of the message is not written in than they will
			 * know to ignore those chars.*/
			messagePlusChars += rand.nextInt(10);
		}
		
		//bArr is the array of bytes of the chars of the message.
		byte[] bArr = messagePlusChars.getBytes("UTF-8");
		/*this number is the amount of iterations i'll have to do through the key to encrypt the message. if the message
		 * is 400 char.s long and the key is 200 char.s long then keyIterations will be 2. it's always a whole number
		 * because i filled in the missing chars.*/
		int keyIterations = bArr.length / keyGroupSize;
		int keysElem;
		byte byteAtKeysElem;
		/*encMessage is enncrypted message. it starts with the number of char.s that were filled in and should be ignored by the
		 * decryptor. a comma separates it from the actual message.*/
		String encMessage = missingChars + ",";
		for(int i = 0; i < keyIterations; i++) {
			for(int keysIndex = 0; keysIndex < key.length; keysIndex++) {
				/*keysIndex uses the index of the element of the key as the index. keysElem uses the key's element at the keysIndex
				 * as the index. e.g. if key = {3}    then keysIndex would be 0, and keysElem would be 3.
				 * i swap the byte at the 0th index of bArr with the byte at the 3rd index of bArr.*/
				keysElem = key[keysIndex];
				/*using the e.g. from the above comment, i store the byte at 3 in byteAtKeysElem, then i move the byte from
				 * 0 into 3, and then i store byteAtKeysElem in 0. while the elements are being moved they have the keysElem added
				 * to it.*/
				/*i add   (keyGroupSize * i)     to each keysIndex and keysElem so that the encrytped message is being dealt with
				 * one key group at a time. on the first iteration through encReq 'i' is 0 so when it's multiplied by keyGroupSize,
				 * 0 will be added to the keysElem and keysIndex. on the second iteration 'i' is 1, so when it's multiplied by
				 * keyGroupSize the keysIndex and keysElem will be the index and elem of the second key group. it uses the same key
				 * values for each key group by having a different base number they're added to; adding one key group's length will
				 * have the indexes refer to the second key group. if i want to get the 0th index on my second iteration (i want to
				 * get the first index of the second key group) of a string with a key group of 4, then adding 4 to get the 0th index
				 * of the second key group will be 4.*/
				byteAtKeysElem = bArr[keysElem + (keyGroupSize * i)];
				bArr[keysElem + (keyGroupSize * i)] = (byte) (bArr[keysIndex + (keyGroupSize * i)] + keysElem);
				bArr[keysIndex + (keyGroupSize * i)] = (byte) (byteAtKeysElem + keysElem);
			}
		}
		for(int b = 0; b < bArr.length; b++) {
			encMessage += bArr[b] + " ";
		}
		//the end of the message has the size the array the decryptor creates should be.
		encMessage += "," + bArr.length;
		System.out.println("enc message length " + encMessage.length());
		System.out.println("arr length " + bArr.length);
		return encMessage;
	}
	
	public String decrypt(String encMessage) {
		/*first i separate the metadata from the actual message. the metadata is the filledInChars and arrSize, and the message is
		 * in between their delineating commas.*/
		String[] messageData = encMessage.split(",");
		int filledInChars = Integer.parseInt(messageData[0]);
		int arrSize = Integer.parseInt(messageData[2]);
		//splits the message at the spaces, meaning each byte is its own element.
		byte[] decArr = splitIntoByteArr(messageData[1], ' ', arrSize);
		int keysElement;
		byte byteAtKeysElement;
		int theKeyIterations = decArr.length / keyGroupSize;
		for(int a = theKeyIterations - 1; a >= 0 ; a--) {
			for(int theKeysIndex = key.length - 1; theKeysIndex >= 0; theKeysIndex--) {
				keysElement = key[theKeysIndex];
				byteAtKeysElement = decArr[keysElement + (keyGroupSize * a)];
				decArr[keysElement + (keyGroupSize * a)] = (byte) (decArr[theKeysIndex + (keyGroupSize * a)] - keysElement);
				decArr[theKeysIndex + (keyGroupSize * a)] = (byte) (byteAtKeysElement - keysElement);
			}
		}
		/*passing in the array returns the bytes converted to chars and as a string. dec is short for decrypted. this string has the
		 * chars that were appended to the message so the key groups could be used.
		 */
		String decMessageWithChars = new String(decArr, StandardCharsets.UTF_8);
		//the decrypted message without the filled in chars at the end.
		String decMessage = decMessageWithChars.substring(0, decMessageWithChars.length() - filledInChars);
		return decMessage;
	}
	
	//str is the string you want split at every splitAtChar char.
	public static byte[] splitIntoByteArr(String str, char splitAtChar, int arraySize) {
		byte[] arr = new byte[arraySize];
		int index = 0;
		String collector = "";
		for(int i = 0; i < str.length(); i++) {
			if(str.charAt(i) == splitAtChar) {
				arr[index] = (byte) Integer.parseInt(collector);
				index++;
				collector = "";
			}
			else {
				collector += str.charAt(i);
			}
		}
		return arr;
	}
}