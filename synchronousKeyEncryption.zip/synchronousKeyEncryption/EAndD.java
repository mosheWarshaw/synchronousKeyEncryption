package synchronousKeyEncryption;
import java.io.UnsupportedEncodingException;
import java.nio.charset.StandardCharsets;
import java.util.Random;
/*my encryption scheme converts the message into an array of the byte value of the chars of the message, and then it scrambles the
 * order of the chars, and while the chars are being scrambled they have a number added to them.
 * the key is an array of the indexes, and the keysIndex is switched with the keysElem. let's say the key is {1} then the
 * keysIndex is 0, and the keysElem is 1. if the message's array (the elements are in decimal form for simplictiy's sake) is
 * {7, 9}, then this key would switch 7 and 9. it would look like {9, 7}. while they're being switched though, keysElem is added to them
 * so it would actually look like {10, 8}.
 * as was just demonstrated with a 1 elem key and a 2 elem message, the key is going to be half the size of the group of chars it will
 * encrypt. if the key is 2 elems and the chars array is 8 elems long then the key will encrypt the first group of 4 elems,
 * and then it will encrypt the second group of 4 elems. if the chars array is 7 elems long then some filler elems
 * will be added to the chars array to create a full second group, and the decryptor will be sent an unencrypted number
 * of how many chars at the end of the message were filler elems that should be ignored.
 * after the scrambling and adding, the bytes are concatenated to a string and can be sent to the
 * decryptor. the decryptor converts the string into an array, and they use the key to unscramble the elems and subtract
 * the number from the chars, and then they convert the array of bytes to a string of chars.*/
//EAndD stands for Encryption And Decryption.
public class EAndD {
	private int[] key;
	private int keyGroupSize;
	public EAndD(int[] keyPar) {
		key = keyPar;
		keyGroupSize = key.length * 2;
	}
	public String encrypt(String origMessage) throws UnsupportedEncodingException {
		Random rand = new Random();
		int missingChars = (int) (keyGroupSize * Math.ceil((double)origMessage.length() / keyGroupSize)) - origMessage.length();		
		String messagePlusChars = origMessage;
		for(int i = 0; i < missingChars; i++) {
			/*a number between 0 and 9 (including both) is generated and used as a filler elem. numbers are more universal than any char
			 * so they're chosen to be the filler chars, and they would not stand out in a message.*/
			messagePlusChars += rand.nextInt(10);
		}
		
		//bArr is the array of bytes of the chars of the message.
		byte[] bArr = messagePlusChars.getBytes("UTF-8");
		int keyIterations = bArr.length / keyGroupSize;
		int keysElem;
		byte byteAtKeysElem;
		//encMessage is encrypted message.
		String encMessage = missingChars + ",";
		for(int i = 0; i < keyIterations; i++) {
			for(int keysIndex = 0; keysIndex < key.length; keysIndex++) {
				keysElem = key[keysIndex];
				/*i add  (keyGroupSize * i)  to each keysIndex and keysElem so that the encrypted message is being dealt with
				 * one key group at a time. on the first iteration through encMessage 'i' is 0 so when it's multiplied by keyGroupSize,
				 * 0 will be added to the keysElem and keysIndex. on the second iteration 'i' is 1, so when it's multiplied by
				 * keyGroupSize the keysIndex and keysElem will be the index and elem of the second key group. adding one key group's length
				 * will have the indexes refer to the second key group. if i want to get the 0th index on my second iteration (i want to
				 * get the 0th index of the second key group) of a string with a key group of 4, then i would add 4.*/
				byteAtKeysElem = bArr[keysElem + (keyGroupSize * i)];
				bArr[keysElem + (keyGroupSize * i)] = (byte) (bArr[keysIndex + (keyGroupSize * i)] + keysElem);
				bArr[keysIndex + (keyGroupSize * i)] = (byte) (byteAtKeysElem + keysElem);
			}
		}
		for(int b = 0; b < bArr.length; b++) {
			//a space is put between each byte so the bytes can be separated when decrypting.
			encMessage += bArr[b] + " ";
		}
		//the end of the message has the size the array the decryptor creates should be.
		encMessage += "," + bArr.length;
		System.out.println("enc message length " + encMessage.length());
		System.out.println("arr length " + bArr.length);
		return encMessage;
	}
	
	public String decrypt(String encMessage) {
		String[] messageData = encMessage.split(",");
		int filledInChars = Integer.parseInt(messageData[0]);
		int arrSize = Integer.parseInt(messageData[2]);
		//dec is short for decrypted.
		byte[] decArr = splitIntoByteArr(messageData[1], ' ', arrSize);
		int keysElement;
		byte byteAtKeysElement;
		int theKeyIterations = decArr.length / keyGroupSize;
		for(int a = theKeyIterations - 1; a >= 0 ; a--) {
			for(int theKeysIndex = key.length - 1; theKeysIndex >= 0; theKeysIndex--) {
				keysElement = key[theKeysIndex];
				byteAtKeysElement = decArr[keysElement + (keyGroupSize * a)];
				decArr[keysElement + (keyGroupSize * a)] = (byte) (decArr[theKeysIndex + (keyGroupSize * a)] - keysElement);
				decArr[theKeysIndex + (keyGroupSize * a)] = (byte) (byteAtKeysElement - keysElement);
			}
		}
		//passing in the array returns a string of the bytes converted back to chars.
		String decMessageWithChars = new String(decArr, StandardCharsets.UTF_8);
		String decMessage = decMessageWithChars.substring(0, decMessageWithChars.length() - filledInChars);
		return decMessage;
	}
	
	//str is the string you want split at every splitAtChar char.
	public byte[] splitIntoByteArr(String str, char splitAtChar, int arraySize) {
		byte[] arr = new byte[arraySize];
		int index = 0;
		String collector = "";
		for(int i = 0; i < str.length(); i++) {
			if(str.charAt(i) == splitAtChar) {
				arr[index] = (byte) Integer.parseInt(collector);
				index++;
				collector = "";
			}
			else {
				collector += str.charAt(i);
			}
		}
		return arr;
	}
}