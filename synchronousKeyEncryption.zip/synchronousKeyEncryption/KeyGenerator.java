package synchronousKeyEncryption;
import java.util.Random;
/*the thread will create as many keys as the number passed into the constructor for the keyAmountsPar value.
 * the user of this class can create multiple instances to use multiple threads to create the amount of keys they want, if the user
 * wants to use more than one thread to create the amount keys they want.*/
public class KeyGenerator extends Thread{
	private int keyGroupSize;
	private int keysAmount;
	final private int KEY_BUFFER_SIZE;
	private int[][] keyBuffer;
	public KeyGenerator(int keyGroupSizePar, int keysAmountPar, int keyBufferSizePar) {
		keyGroupSize = keyGroupSizePar;
		keysAmount = keysAmountPar;
		KEY_BUFFER_SIZE = keyBufferSizePar;
		/*this will be a buffer of keys that will store them more than one at a time instead of calling the storeKey after
		 * every key is created.*/
		keyBuffer = new int[KEY_BUFFER_SIZE][keyGroupSize / 2];
	}
	@Override
	public void run() {
		int keyElem;
		Random rand = new Random();
		/*the outermost for loop ensures that the amount of keys are created that are supposed to be, but it's incremented
		 * KEY_BUFER_SIZE each iteration, because the middle for loop does this amount of keys at a time, and then calls the
		 * storeKeyBuffer method on it, and the innermost for loop fills each key array.*/
		for(int keyCounter = 0; keyCounter < keysAmount; keyCounter += KEY_BUFFER_SIZE) {
			for(int keyBufferIndex = 0; keyBufferIndex < KEY_BUFFER_SIZE; keyBufferIndex++) {
				for(int keyIndex = 0; keyIndex < (keyGroupSize / 2); keyIndex++) {
					keyElem = rand.nextInt(keyGroupSize);
					keyBuffer[keyBufferIndex][keyIndex] = keyElem;
				}
			}
			storeKeyBuffer(keyBuffer);
			keyBuffer = new int[KEY_BUFFER_SIZE][keyGroupSize / 2];
		}
	}
	public void storeKeyBuffer(int[][] keys) {
		/*this is an empty method that has the key buffer that was just created passed into it, and it's because i haven't
		 * learned databases yet, so i'm not doing anything with these keys that i create.*/
		//i added this printing for debugging so i can see if it's working. u can uncomment it out if you have to debug again.
		/*for(int a = 0; a < keys.length; a++) {
			for(int b = 0; b < keyGroupSize / 2; b++) {
				try {
					System.out.print(keys[a][b] + ",");
				}
				catch(Exception e) {}
			}
			System.out.print("\n");
		}*/
	}
}