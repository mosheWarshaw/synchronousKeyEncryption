package synchronousKeyEncryption;
import java.util.Random;
/*the thread will create as many keys as the number passed into the constructor for the keyAmountsPar value.
 * the user of this class can create multiple instances to use multiple threads to create the amount of keys they want.*/
public class KeyGenerator extends Thread{
	private int keyGroupSize;
	private int keysAmount;
	final private int KEY_BUFFER_SIZE;
	private int[][] keyBuffer;
	public KeyGenerator(int keyGroupSizePar, int keysAmountPar, int keyBufferSizePar) {
		keyGroupSize = keyGroupSizePar;
		keysAmount = keysAmountPar;
		KEY_BUFFER_SIZE = keyBufferSizePar;
		//this will be a buffer of keys so i don't have to call the storeKey method after every key is created.
		keyBuffer = new int[KEY_BUFFER_SIZE][keyGroupSize / 2];
	}
	@Override
	public void run() {
		Random rand = new Random();
		/*the innermost for loop creates a key by filling in random indexes as the elems. the middle for loop runs the inner loop the
		 * amount of times it will take to fill the buffer, and the outermost for loop runs the middle for loop so the amount of key
		 * buffers are created that should be.*/
		for(int keyCounter = 0; keyCounter < keysAmount; keyCounter += KEY_BUFFER_SIZE) {
			for(int keyBufferIndex = 0; keyBufferIndex < KEY_BUFFER_SIZE; keyBufferIndex++) {
				for(int keyIndex = 0; keyIndex < (keyGroupSize / 2); keyIndex++) {
					keyBuffer[keyBufferIndex][keyIndex] = rand.nextInt(keyGroupSize);
				}
			}
			storeKeyBuffer(keyBuffer);
		}
	}
	public void storeKeyBuffer(int[][] keys) {
		/*this is an empty method because i haven't learned databases yet, and i want to learn that before writing a method that would
		 * simulate storing the keys.*/
	}
}